const express = require('express');
const amqp = require('amqplib');
const http = require('http');

if (!process.env.RABBIT) {
    throw new Error('Please specify the name of the RabbitMQ host using environment variable RABBIT');
}

const RABBIT = process.env.RABBIT;

//
// Connect to the RabbitMQ server.
//
function connectRabbit() {

        console.log(`Connecting to RabbitMQ server at ${RABBIT}.`);

        return amqp.connect(RABBIT) // Connect to the RabbitMQ server.
            .then(connection => {
                console.log('Connected to RabbitMQ.');

                return connection.createChannel() // Create a RabbitMQ messaging channel.
                    .then(messageChannel => {
                        return messageChannel.assertExchange('viewed', 'fanout') // Assert that we have a "viewed" exchange.
                            .then(() => {
                                return messageChannel;
                            });
                    });
            });
}

//
// Broadcast the "viewed" message.
//
function broadcastViewedMessage(messageChannel, advertisingId) {
    console.log(`Publishing message on "viewed" exchange.`);

    const msg = { advertising: { id: advertisingId } };
    const jsonMsg = JSON.stringify(msg);
    messageChannel.publish('viewed', '', Buffer.from(jsonMsg)); // Publish message to the "viewed" exchange.
}

//
// Setup event handlers.
//
function setupHandlers(app, messageChannel) {
    app.get('/advertising', (req, res) => { // Route for advertising link.
        const advertisingId = req.query.id;

        const forwardRequest = http.request( // Forward the request to the advertising storage microservice.
            {
                host: `advertising-storage`,
                path: `/advertising?id=${advertisingId}`,
                method: 'GET',
                headers: req.headers,
            },
            forwardResponse => {
                res.writeHeader(forwardResponse.statusCode, forwardResponse.headers);
                forwardResponse.pipe(res);
            });

        forwardRequest.on('error', e => {
            console.error(`Error forwarding request: ${e.message}`);
            res.status(500).send('Error forwarding request.');
        });

        forwardRequest.end();
        broadcastViewedMessage(messageChannel, advertisingId); // Broadcast the "viewed" message.
    });
}
function startHttpServer(messageChannel) {
    return new Promise(resolve => { // Wrap in a promise so we can be notified when the server has started.
        const app = express();
        setupHandlers(app, messageChannel);

        const port = process.env.PORT && parseInt(process.env.PORT) || 3000;
        app.listen(port, () => {
            resolve(); // HTTP server is listening, resolve the promise.
        });
    });
}
function main() {
    return connectRabbit()                          // Connect to RabbitMQ...
        .then(messageChannel => {                   // then...
            return startHttpServer(messageChannel); // start the HTTP server.
        });
}

main()
    .then(() => console.log("Microservice online."))
    .catch(err => {
        console.error("Microservice failed to start.");
        console.error(err && err.stack || err);
    });