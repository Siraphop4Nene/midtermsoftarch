const mongodb = require("mongodb");

module.exports = [
    {
        _id: mongodb.ObjectId("1"),
        name: "Youtube",
        link: "https://www.google.com/search?q=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D9bZkp7q19f0#fpstate=ive&vld=cid:daeb49c2,vid:9bZkp7q19f0"
    }
];