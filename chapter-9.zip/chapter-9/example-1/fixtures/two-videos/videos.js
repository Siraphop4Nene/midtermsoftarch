const mongodb = require("mongodb");

module.exports = [
    {
        _id: mongodb.ObjectId("5ea234a1c34230004592eb32"),
        name: "SampleVideo_1280x720_1mb.mp4"
    },
    {
        _id: mongodb.ObjectId("5ea234a5c34230004592eb33"),
        name: "Another video.mp4"
    }
];